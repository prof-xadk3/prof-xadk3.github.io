export async function root() {
  return "Nick was here!";
}
