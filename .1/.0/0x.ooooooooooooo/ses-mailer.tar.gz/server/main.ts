function add(x: number, y: number) {
  return x + y;
}

exports.add = add;
