
export const HomePage = () => {
  return (
    <section class="homepage">
      <h1> Welcome to the SES utility software. </h1>
    </section>
  );
};
